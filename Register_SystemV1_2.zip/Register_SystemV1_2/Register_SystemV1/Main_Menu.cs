﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Register_SystemV1
{
    public partial class Main_Menu :MaterialSkin.Controls.MaterialForm
    {
        public Main_Menu()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void StudentsBTN_Click(object sender, EventArgs e)
        {
            Student_Registration obj = new Student_Registration();
            obj.Show(); 

        }

        private void RegistrationBTN_Click(object sender, EventArgs e)
        {

            Attendance_Registration ar = new Attendance_Registration();
            ar.Show();

        }

        private void CourseBTN_Click(object sender, EventArgs e)
        {

            Student_Report sr = new Student_Report();
            sr.Show();
        }

        private void ClassBTN_Click(object sender, EventArgs e)
        {

            Class_and_Course cc = new Class_and_Course();
            cc.Show();
        }

        private void LecturerBTN_Click(object sender, EventArgs e)
        {

            Lecturer l = new Lecturer();
            l.Show();
        }

        private void LogoutBTN_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 lp = new Form1();
            lp.Show();
        }
    }
}
