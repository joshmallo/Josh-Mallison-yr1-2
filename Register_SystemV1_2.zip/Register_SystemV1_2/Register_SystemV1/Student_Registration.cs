﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Register_SystemV1
{
    public partial class Student_Registration : MaterialSkin.Controls.MaterialForm
    {
        public Student_Registration()
        {
            InitializeComponent();
        }

        private void Student_Registration_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main_Menu fm = new Main_Menu();
            fm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Student Form Successfully added");
        }
    }
}
