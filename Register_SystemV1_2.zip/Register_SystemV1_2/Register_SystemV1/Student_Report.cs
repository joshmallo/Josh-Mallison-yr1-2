﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Register_SystemV1
{
    public partial class Student_Report : MaterialSkin.Controls.MaterialForm
    {
        /*private DataTable dt;
        private DataView dv;
        private List<Student> students;*/
        public Student_Report()
        {
            InitializeComponent();

            /*listView1.View = View.Details;
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);

            dt = new DataTable();
            dt.Columns.Add("students");*/
        }

        private void Student_Report_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
/*class Student
{
    private string studentID;
    private string name;
    private string studentClass;

    public Student(string studentID, string name, string studentClass)
    {
        this.studentID = studentID;
        this.name = name;
        this.studentClass = studentClass;

    }

    public string StudentID
    {
        get { return studentID; }
    }
    public string Name
    {
        get { return name; }
    }
    public string StudentClass
    {
        get { return studentClass; }
    }*/
//}
