﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Register_SystemV1
{
    public partial class Class_and_Course : MaterialSkin.Controls.MaterialForm
    {
        public Class_and_Course()
        {
            InitializeComponent();
        }

        private void Class_and_Course_Load(object sender, EventArgs e)
        {

        }
    }
}
