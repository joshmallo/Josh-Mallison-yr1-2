﻿
namespace Register_SystemV1
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.LogoutBTN = new System.Windows.Forms.Button();
            this.LecturerBTN = new System.Windows.Forms.Button();
            this.ClassBTN = new System.Windows.Forms.Button();
            this.ReportBTN = new System.Windows.Forms.Button();
            this.RegistrationBTN = new System.Windows.Forms.Button();
            this.StudentsBTN = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LogoutBTN);
            this.panel1.Controls.Add(this.LecturerBTN);
            this.panel1.Controls.Add(this.ClassBTN);
            this.panel1.Controls.Add(this.ReportBTN);
            this.panel1.Controls.Add(this.RegistrationBTN);
            this.panel1.Controls.Add(this.StudentsBTN);
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.panel1.Location = new System.Drawing.Point(0, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(211, 645);
            this.panel1.TabIndex = 0;
            // 
            // LogoutBTN
            // 
            this.LogoutBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.LogoutBTN.BackgroundImage = global::Register_SystemV1.Properties.Resources.logout_icon_151219;
            this.LogoutBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.LogoutBTN.ForeColor = System.Drawing.Color.Black;
            this.LogoutBTN.Location = new System.Drawing.Point(42, 538);
            this.LogoutBTN.Name = "LogoutBTN";
            this.LogoutBTN.Size = new System.Drawing.Size(125, 62);
            this.LogoutBTN.TabIndex = 5;
            this.LogoutBTN.Text = "Logout";
            this.LogoutBTN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LogoutBTN.UseVisualStyleBackColor = false;
            this.LogoutBTN.Click += new System.EventHandler(this.LogoutBTN_Click);
            // 
            // LecturerBTN
            // 
            this.LecturerBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.LecturerBTN.BackgroundImage = global::Register_SystemV1.Properties.Resources.teacher;
            this.LecturerBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.LecturerBTN.ForeColor = System.Drawing.Color.Black;
            this.LecturerBTN.Location = new System.Drawing.Point(42, 426);
            this.LecturerBTN.Name = "LecturerBTN";
            this.LecturerBTN.Size = new System.Drawing.Size(125, 54);
            this.LecturerBTN.TabIndex = 4;
            this.LecturerBTN.Text = "Lecturer";
            this.LecturerBTN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LecturerBTN.UseVisualStyleBackColor = false;
            this.LecturerBTN.Click += new System.EventHandler(this.LecturerBTN_Click);
            // 
            // ClassBTN
            // 
            this.ClassBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.ClassBTN.BackgroundImage = global::Register_SystemV1.Properties.Resources.Class_Icon;
            this.ClassBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClassBTN.ForeColor = System.Drawing.Color.Black;
            this.ClassBTN.Location = new System.Drawing.Point(42, 327);
            this.ClassBTN.Name = "ClassBTN";
            this.ClassBTN.Size = new System.Drawing.Size(125, 52);
            this.ClassBTN.TabIndex = 3;
            this.ClassBTN.Text = "Class/Course";
            this.ClassBTN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ClassBTN.UseVisualStyleBackColor = false;
            this.ClassBTN.Click += new System.EventHandler(this.ClassBTN_Click);
            // 
            // ReportBTN
            // 
            this.ReportBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.ReportBTN.BackgroundImage = global::Register_SystemV1.Properties.Resources.Course_Icon;
            this.ReportBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ReportBTN.ForeColor = System.Drawing.Color.Black;
            this.ReportBTN.Location = new System.Drawing.Point(42, 229);
            this.ReportBTN.Name = "ReportBTN";
            this.ReportBTN.Size = new System.Drawing.Size(125, 52);
            this.ReportBTN.TabIndex = 2;
            this.ReportBTN.Text = "Reports";
            this.ReportBTN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ReportBTN.UseVisualStyleBackColor = false;
            this.ReportBTN.Click += new System.EventHandler(this.CourseBTN_Click);
            // 
            // RegistrationBTN
            // 
            this.RegistrationBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.RegistrationBTN.BackgroundImage = global::Register_SystemV1.Properties.Resources.Register_Icon;
            this.RegistrationBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.RegistrationBTN.ForeColor = System.Drawing.Color.Black;
            this.RegistrationBTN.Location = new System.Drawing.Point(42, 133);
            this.RegistrationBTN.Name = "RegistrationBTN";
            this.RegistrationBTN.Size = new System.Drawing.Size(125, 60);
            this.RegistrationBTN.TabIndex = 1;
            this.RegistrationBTN.Text = "Registration";
            this.RegistrationBTN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.RegistrationBTN.UseVisualStyleBackColor = false;
            this.RegistrationBTN.Click += new System.EventHandler(this.RegistrationBTN_Click);
            // 
            // StudentsBTN
            // 
            this.StudentsBTN.BackgroundImage = global::Register_SystemV1.Properties.Resources.Student_Icon_new1_0;
            this.StudentsBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.StudentsBTN.ForeColor = System.Drawing.Color.Black;
            this.StudentsBTN.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentsBTN.Location = new System.Drawing.Point(42, 29);
            this.StudentsBTN.Name = "StudentsBTN";
            this.StudentsBTN.Size = new System.Drawing.Size(125, 58);
            this.StudentsBTN.TabIndex = 0;
            this.StudentsBTN.Text = "Students";
            this.StudentsBTN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.StudentsBTN.UseVisualStyleBackColor = false;
            this.StudentsBTN.Click += new System.EventHandler(this.StudentsBTN_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Register_SystemV1.Properties.Resources.BUE_Buliding_3;
            this.pictureBox1.Location = new System.Drawing.Point(207, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1074, 642);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.ClientSize = new System.Drawing.Size(1280, 705);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Main_Menu";
            this.Text = "Main_Menu";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button LogoutBTN;
        private System.Windows.Forms.Button LecturerBTN;
        private System.Windows.Forms.Button ClassBTN;
        private System.Windows.Forms.Button ReportBTN;
        private System.Windows.Forms.Button RegistrationBTN;
        private System.Windows.Forms.Button StudentsBTN;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}